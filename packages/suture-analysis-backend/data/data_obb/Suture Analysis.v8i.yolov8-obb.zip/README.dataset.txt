# Suture Analysis > 2024-10-30 5:57am
https://universe.roboflow.com/suture-analysis-data-labeling/suture-analysis-dnuqd

Provided by a Roboflow user
License: MIT

