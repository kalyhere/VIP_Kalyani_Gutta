# Suture Analysis > 2024-10-21 7:17am
https://universe.roboflow.com/suture-analysis-data-labeling/suture-analysis-dnuqd

Provided by a Roboflow user
License: MIT

