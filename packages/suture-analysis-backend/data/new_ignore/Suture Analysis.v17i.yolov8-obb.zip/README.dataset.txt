# Suture Analysis > 2024-11-20 12:10am
https://universe.roboflow.com/suture-analysis-data-labeling/suture-analysis-dnuqd

Provided by a Roboflow user
License: MIT

